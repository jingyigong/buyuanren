function rs() {
  document.getElementById('divb').style.height = 
  document.body.clientHeight-
  document.getElementById('divh').clientHeight-1;
}
